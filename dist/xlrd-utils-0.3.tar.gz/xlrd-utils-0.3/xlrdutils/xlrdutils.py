'''
Created on Jun 2, 2015

@author: grovesr
'''

if __name__ == '__main__':
    pass

import re, xlrd, pytz
from datetime import datetime

def open_workbook(filename=None, file_contents=None):
    try:
        if filename:
            workbook=xlrd.open_workbook(filename=filename)
        elif file_contents:
            workbook=xlrd.open_workbook(file_contents=file_contents)
        else:
            raise xlrd.XLRDError
    except xlrd.XLRDError:
        raise xlrd.XLRDError
        return -1
    return workbook

def read_header(sheet,headerKeyText=''):

    foundHeader=False
    for rowIndex in range(sheet.nrows):
        thisLineHeaders=[]
        for colIndex in range(sheet.ncols):
            cell=sheet.cell(rowIndex,colIndex).value
            if not foundHeader and re.match(headerKeyText,str(cell),re.IGNORECASE):
                # assume we found a header line if headerText is found in any of the cells
                foundHeader=True
            thisLineHeaders.append(cell)
        if foundHeader:
            return(thisLineHeaders,rowIndex)
    # No headers in the file
    return (-1,-1)

def read_lines(workbook, sheet='', headerKeyText='', zone=None):
    try:
        # 
        try:
            sheet = workbook.sheet_by_name(sheet)
        except xlrd.XLRDError:
            if workbook.nsheets == 1:
                try:
                    sheet = workbook.sheet_by_index(0)
                except xlrd.XLRDError:
                    return -1
            else:
                return -1
        headers,headerLine=read_header(sheet,headerKeyText)
        if headers == -1 or headerLine == -1:
            return -1
        data={}
        #fill dict with empty lists, one for each header key
        for header in headers:
            data[header]=[]
        for rowIndex in range(sheet.nrows):
            # Find the header row
            if rowIndex > headerLine:
                # Assume rows after the header row contain line items
                # run through the columns and add the data to the data dict 
                for colIndex in range(sheet.ncols):
                    cell=sheet.cell(rowIndex,colIndex)
                    # parse the cell information base on cell type
                    if cell.ctype == xlrd.XL_CELL_TEXT:
                        data[headers[colIndex]].append(cell.value.strip())
                    elif cell.ctype == xlrd.XL_CELL_EMPTY:
                        data[headers[colIndex]].append('')
                    elif cell.ctype == xlrd.XL_CELL_NUMBER:
                        data[headers[colIndex]].append(cell.value)
                    elif cell.ctype == xlrd.XL_CELL_DATE:
                        data[headers[colIndex]].append(parse_date(workbook,cell.value,zone=zone))
                    else:
                        # unspecified cell type, just output a blank
                        data[headers[colIndex]].append('')
    except xlrd.XLRDError:
        return -1
    if headerLine == 1e6:
        # we never found a header line
        return -1
    return data 

def parse_date(workbook,cell,zone=None):
    #format: excel date object
    if not zone:
        zone='UTC'
    localZone=pytz.timezone(zone)
    if isinstance(cell,str) or isinstance(cell,unicode):
        if len(cell) == 0:
            # just return the empty string
            return cell
        else:
            # if this is a string make sure we can parse it into a date
            try:
                dateVal=datetime.strptime(cell,'%m/%d/%y %H:%M:%S')
                dateTuple=dateVal.year,dateVal.month,dateVal.day,dateVal.hour,\
                dateVal.minute,dateVal.second
                dateVal=datetime(*dateTuple)
                # tag the date as being from the local time zone
                dateVal=localZone.localize(dateVal, is_dst=0)
                # convert it to UTC time zone for saving to database
                dateVal=dateVal.astimezone(pytz.utc)
            except:
                # if we can't just return None
                return None
            print "found string "+repr(dateVal)
            return dateVal
    else:
        timeVal =xlrd.xldate_as_tuple(cell,workbook.datemode)
        dateVal=datetime(*timeVal)
        # tag the date as being from the local time zone
        dateVal=localZone.localize(dateVal, is_dst=0)
        # convert it to UTC time zone for saving to database
        dateVal=dateVal.astimezone(pytz.utc)
    return dateVal
    