=====
xlrdutils
=====

xlrdutils provide simple add-on functions to xlrd for converting a spreadsheet
into a dictionary 
