'''
Created on Jun 2, 2015

@author: grovesr
'''

if __name__ == '__main__':
    pass

import re, xlrd, datetime

def open_workbook(filename=None, file_contents=None):
    try:
        if filename:
            workbook=xlrd.open_workbook(filename=filename)
        elif file_contents:
            workbook=xlrd.open_workbook(file_contents=file_contents)
        else:
            raise Exception
    except Exception as e:
        return -1
    return workbook

def read_header(sheet,headerKeyText=''):

    foundHeader=False
    for rowIndex in range(sheet.nrows):
        thisLineHeaders=[]
        for colIndex in range(sheet.ncols):
            cell=sheet.cell(rowIndex,colIndex).value
            if re.match(headerKeyText,cell,re.IGNORECASE) and not foundHeader:
                # assume we found a header line if headerText is found in any of the cells
                foundHeader=True
            thisLineHeaders.append(cell)
        if foundHeader:
            return(thisLineHeaders,rowIndex)
    # No headers in the file
    return (-1,-1)

def read_lines(workbook,headerKeyText=''):
    try:
        # Assume that the first sheet is the one to parse
        sheet = workbook.sheet_by_index(0)
        headers,headerLine=read_header(sheet,headerKeyText)
        data={}
        #fill dict with empty lists, one for each header key
        for header in headers:
            data[header]=[]
        for rowIndex in range(sheet.nrows):
            # Find the header row
            if rowIndex > headerLine:
                # Assume rows after the header row contain line items
                # run through the columns and add the data to the data dict 
                for colIndex in range(sheet.ncols):
                    cell=sheet.cell(rowIndex,colIndex)
                    # parse the cell information base on cell type
                    if cell.ctype == xlrd.XL_CELL_TEXT:
                        data[headers[colIndex]].append(cell.value.strip())
                    elif cell.ctype == xlrd.XL_CELL_EMPTY:
                        data[headers[colIndex]].append('')
                    elif cell.ctype == xlrd.XL_CELL_NUMBER:
                        data[headers[colIndex]].append(cell.value)
                    elif cell.ctype == xlrd.XL_CELL_DATE:
                        data[headers[colIndex]].append(parse_date(workbook,cell))
                    else:
                        # unspecified cell type, just output a blank
                        data[headers[colIndex]].append('')
    except Exception:
        return -1
    if headerLine == 1e6:
        # we never found a header line
        return -1
    return data 

def parse_date(workbook,cell):
    #format: excel date object
    timeValue =xlrd.xldate_as_tuple(cell.value,workbook.datemode)
    return datetime(*timeValue).strftime('%m/%d/%y %H:%M:%S')
    